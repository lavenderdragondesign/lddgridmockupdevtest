// components/FreeformCanvas.tsx
import React, { useRef, useEffect, useState, useCallback } from 'react';
import type { ImageState } from '../types';

/**
 * Freeform canvas with per-image drag, wheel zoom under cursor,
 * hold R to rotate, optional grid overlay + snapping, and keyboard nudges.
 */
type Item = {
  id: string;
  img: HTMLImageElement;
  x: number;
  y: number;
  scale: number;
  rotation: number; // radians
};

type Props = {
  images: ImageState[];
};

export default function FreeformCanvas({ images }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [size, setSize] = useState<{w:number; h:number}>({ w: 800, h: 800 });

  // UI state
  const [showGrid, setShowGrid] = useState(true);
  const [snap, setSnap] = useState(true);
  const [gridSize, setGridSize] = useState(40);
  const [showHelp, setShowHelp] = useState(false);

  // Refs to avoid re-adding listeners during drags
  const draggingRef = useRef(false);
  const dragOffsetRef = useRef<{dx:number; dy:number} | null>(null);
  const rotatingRef = useRef(false);
  const activeIdRef = useRef<string | null>(null);
  const itemsRef = useRef<Item[]>([]);

  // keep refs in sync
  useEffect(() => { itemsRef.current = items; }, [items]);
  useEffect(() => { activeIdRef.current = activeId; }, [activeId]);

  // measure parent size
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = canvas.parentElement;
    if (!parent) return;

    const ro = new ResizeObserver(() => {
      const rect = parent.getBoundingClientRect();
      setSize({ w: Math.max(100, rect.width), h: Math.max(100, rect.height) });
    });
    ro.observe(parent);
    const rect = parent.getBoundingClientRect();
    setSize({ w: Math.max(100, rect.width), h: Math.max(100, rect.height) });
    return () => ro.disconnect();
  }, []);

  // preload images & initialize layout if new
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const existing = new Map(itemsRef.current.map(i => [i.id, i]));
      const next: Item[] = [];
      let idx = 0;
      for (const im of images) {
        const prev = existing.get(im.id);
        const el = new Image();
        el.crossOrigin = 'anonymous';
        el.src = im.url;
        await new Promise<void>((res) => {
          if (el.complete) return res();
          el.onload = () => res();
          el.onerror = () => res();
        });
        if (cancelled) return;
        if (prev) {
          next.push({ ...prev, img: el });
        } else {
          const angle = (idx / Math.max(1, images.length)) * Math.PI * 2;
          const radius = 60 + (idx % 5) * 25;
          next.push({
            id: im.id,
            img: el,
            x: size.w / 2 + Math.cos(angle) * radius,
            y: size.h / 2 + Math.sin(angle) * radius,
            scale: 0.4,
            rotation: 0
          });
        }
        idx++;
      }
      if (!cancelled) setItems(next);
    })();
    return () => { cancelled = true; }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [images.map(i => i.id + ':' + i.url).join('|')]);

  const dpr = Math.max(1, (typeof window !== 'undefined' && window.devicePixelRatio) ? window.devicePixelRatio : 1);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { w, h } = size;
    const pw = Math.floor(w * dpr);
    const ph = Math.floor(h * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    // grid
    if (showGrid) {
      ctx.save();
      ctx.strokeStyle = 'rgba(0,0,0,0.07)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x + 0.5, 0);
        ctx.lineTo(x + 0.5, h);
        ctx.stroke();
      }
      for (let y = 0; y <= h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y + 0.5);
        ctx.lineTo(w, y + 0.5);
        ctx.stroke();
      }
      // darker axes
      ctx.strokeStyle = 'rgba(0,0,0,0.15)';
      ctx.beginPath(); ctx.moveTo(w/2, 0); ctx.lineTo(w/2, h); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, h/2); ctx.lineTo(w, h/2); ctx.stroke();
      ctx.restore();
    }

    for (const it of itemsRef.current) {
      const iw = it.img.naturalWidth || 1;
      const ih = it.img.naturalHeight || 1;
      ctx.save();
      ctx.translate(it.x, it.y);
      ctx.rotate(it.rotation);
      ctx.scale(it.scale, it.scale);
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(it.img, -iw/2, -ih/2);
      if (it.id === activeIdRef.current) {
        ctx.setLineDash([6/it.scale, 6/it.scale]);
        ctx.lineWidth = 2/it.scale;
        ctx.strokeStyle = '#22c55e';
        ctx.strokeRect(-iw/2, -ih/2, iw, ih);
      }
      ctx.restore();
    }
  }, [size, dpr, showGrid, gridSize]);

  useEffect(() => { draw(); }, [draw, items, activeId, showGrid, gridSize]);

  // helpers
  const clientToCanvas = useCallback((e: MouseEvent | WheelEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const cx = (e as MouseEvent).clientX ?? (e as WheelEvent).clientX;
    const cy = (e as MouseEvent).clientY ?? (e as WheelEvent).clientY;
    const x = (cx - rect.left) * (size.w / rect.width);
    const y = (cy - rect.top) * (size.h / rect.height);
    return { x, y };
  }, [size]);

  const hitTest = useCallback((px: number, py: number) => {
    const list = itemsRef.current;
    for (let i = list.length - 1; i >= 0; i--) {
      const it = list[i];
      const iw = it.img.naturalWidth || 1;
      const ih = it.img.naturalHeight || 1;
      const tx = px - it.x;
      const ty = py - it.y;
      const cos = Math.cos(-it.rotation);
      const sin = Math.sin(-it.rotation);
      const rx = (tx * cos - ty * sin) / it.scale;
      const ry = (tx * sin + ty * cos) / it.scale;
      if (rx >= -iw/2 && rx <= iw/2 && ry >= -ih/2 && ry <= ih/2) {
        return { i, it };
      }
    }
    return null;
  }, []);

  // Stable native listeners (empty deps)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const setAndRedraw = (next: Item[] | ((p: Item[]) => Item[])) => {
      setItems(prev => {
        const out = typeof next === 'function' ? (next as any)(prev) : next;
        return out;
      });
    };

    const onMouseDown = (e: MouseEvent) => {
      const { x, y } = clientToCanvas(e);
      const hit = hitTest(x, y);
      if (hit) {
        draggingRef.current = true;
        setActiveId(hit.it.id);
        activeIdRef.current = hit.it.id;
        // bring to top
        setAndRedraw(prev => {
          const next = prev.slice();
          const found = next.findIndex(p => p.id === hit.it.id);
          if (found >= 0) {
            const [sp] = next.splice(found, 1);
            next.push(sp);
          }
          return next;
        });
        dragOffsetRef.current = { dx: x - hit.it.x, dy: y - hit.it.y };
      } else {
        setActiveId(null);
        activeIdRef.current = null;
        dragOffsetRef.current = null;
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!draggingRef.current || !dragOffsetRef.current || !activeIdRef.current) return;
      const { x, y } = clientToCanvas(e);
      const { dx, dy } = dragOffsetRef.current;
      let nx = x - dx;
      let ny = y - dy;

      const altDown = (e as any).altKey;
      if (snap && !altDown) {
        const g = gridSize;
        nx = Math.round(nx / g) * g;
        ny = Math.round(ny / g) * g;
      }

      const id = activeIdRef.current;
      setAndRedraw(prev => prev.map(p => p.id === id ? { ...p, x: nx, y: ny } : p));
    };

    const onMouseUp = () => {
      draggingRef.current = false;
      dragOffsetRef.current = null;
      rotatingRef.current = false;
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'r') {
        rotatingRef.current = true;
        // focus canvas for subsequent keys
        (canvas as any).focus?.();
      }
      // arrow key nudge
      if (activeIdRef.current) {
        const step = e.shiftKey ? 10 : 1;
        let dx = 0, dy = 0;
        if (e.key === 'ArrowLeft') dx = -step;
        if (e.key === 'ArrowRight') dx = step;
        if (e.key === 'ArrowUp') dy = -step;
        if (e.key === 'ArrowDown') dy = step;
        if (dx || dy) {
          e.preventDefault();
          const id = activeIdRef.current;
          setAndRedraw(prev => prev.map(p => p.id === id ? { ...p, x: p.x + dx, y: p.y + dy } : p));
        }
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'r') rotatingRef.current = false;
    };

    const onMouseMoveRotate = (e: MouseEvent) => {
      if (!rotatingRef.current || !activeIdRef.current) return;
      const { x, y } = clientToCanvas(e);
      const id = activeIdRef.current;
      const it = itemsRef.current.find(i => i.id === id);
      if (!it) return;
      const ang = Math.atan2(y - it.y, x - it.x);
      setAndRedraw(prev => prev.map(p => p.id === id ? { ...p, rotation: ang } : p));
    };

    const onWheel = (e: WheelEvent) => {
      if (!activeIdRef.current) return;
      e.preventDefault();
      const delta = Math.sign(e.deltaY) * -0.08;
      const id = activeIdRef.current;
      setAndRedraw(prev => prev.map(p => p.id === id ? { ...p, scale: Math.min(5, Math.max(0.1, p.scale * (1 + delta))) } : p));
    };

    canvas.tabIndex = 0;

    canvas.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    canvas.addEventListener('mousemove', onMouseMoveRotate);
    canvas.addEventListener('keydown', onKeyDown);
    canvas.addEventListener('keyup', onKeyUp);
    canvas.addEventListener('wheel', onWheel, { passive: false });

    return () => {
      canvas.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      canvas.removeEventListener('mousemove', onMouseMoveRotate);
      canvas.removeEventListener('keydown', onKeyDown);
      canvas.removeEventListener('keyup', onKeyUp);
      canvas.removeEventListener('wheel', onWheel as any);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientToCanvas, hitTest, snap, gridSize]);

  useEffect(() => { draw(); }, [items, activeId, size, showGrid, gridSize, draw]);

  return (
    <>
      {/* Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 w-full h-full outline-none"
        aria-label="Freeform canvas"
        style={{ cursor: rotatingRef.current ? 'grab' : 'default' }}
      />

      {/* Floating controls */}
      <div className="absolute top-2 left-2 bg-black/70 text-white rounded-lg p-2 space-y-2 shadow-lg">
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1 text-xs">
            <input type="checkbox" checked={showGrid} onChange={e => setShowGrid(e.target.checked)} />
            Grid
          </label>
          <label className="flex items-center gap-1 text-xs">
            <input type="checkbox" checked={snap} onChange={e => setSnap(e.target.checked)} />
            Snap
          </label>
          <label className="flex items-center gap-1 text-xs">
            Size
            <input type="range" min={8} max={200} step={2} value={gridSize} onChange={e => setGridSize(Number(e.target.value))} />
            <span className="tabular-nums text-[10px]">{gridSize}px</span>
          </label>
          <button className="text-xs px-2 py-1 bg-lime-600 rounded hover:bg-lime-500" onClick={() => setShowHelp(h => !h)}>
            {showHelp ? 'Hide' : 'Help'}
          </button>
        </div>
        {showHelp && (
          <div className="text-[10px] leading-tight space-y-1">
            <div><b>Drag</b>: Left mouse on image (hold <b>Alt</b> to ignore snap)</div>
            <div><b>Zoom</b>: Mouse wheel over selected image</div>
            <div><b>Rotate</b>: Hold <b>R</b> and move mouse</div>
            <div><b>Nudge</b>: Arrow keys (hold Shift = 10px)</div>
            <div><b>Select top-most</b>: Click the image</div>
          </div>
        )}
      </div>
    </>
  );
}
