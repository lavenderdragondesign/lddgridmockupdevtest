
export const FONT_FACES: string[] = [
  'Montserrat',
  'Roboto',
  'Open Sans',
  'Lato',
  'Playfair Display',
  'Poppins',
  'Arial',
  'Verdana',
  'Georgia',
  'Times New Roman',
  'Courier New',
];